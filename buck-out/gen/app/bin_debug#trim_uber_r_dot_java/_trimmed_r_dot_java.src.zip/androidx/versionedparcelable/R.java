package androidx.versionedparcelable;

public class R {}
