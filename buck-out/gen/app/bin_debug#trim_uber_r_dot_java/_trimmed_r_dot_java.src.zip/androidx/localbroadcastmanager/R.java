package androidx.localbroadcastmanager;

public class R {}
