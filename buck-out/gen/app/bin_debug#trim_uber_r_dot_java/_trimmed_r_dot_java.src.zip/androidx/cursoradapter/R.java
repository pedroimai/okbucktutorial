package androidx.cursoradapter;

public class R {}
