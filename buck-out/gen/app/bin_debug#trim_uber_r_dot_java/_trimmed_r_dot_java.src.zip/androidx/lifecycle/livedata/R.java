package androidx.lifecycle.livedata;

public class R {}
