package androidx.lifecycle.livedata.core;

public class R {}
