package androidx.appcompat.resources;

public class R {
  public static class attr {
    public static final int alpha=0x7f01014d;
    public static final int coordinatorLayoutStyle=0x7f010144;
    public static final int font=0x7f010155;
    public static final int fontProviderAuthority=0x7f01014e;
    public static final int fontProviderCerts=0x7f010151;
    public static final int fontProviderFetchStrategy=0x7f010152;
    public static final int fontProviderFetchTimeout=0x7f010153;
    public static final int fontProviderPackage=0x7f01014f;
    public static final int fontProviderQuery=0x7f010150;
    public static final int fontStyle=0x7f010154;
    public static final int fontVariationSettings=0x7f010039;
    public static final int fontWeight=0x7f010156;
    public static final int keylines=0x7f010145;
    public static final int layout_anchor=0x7f010148;
    public static final int layout_anchorGravity=0x7f01014a;
    public static final int layout_behavior=0x7f010147;
    public static final int layout_dodgeInsetEdges=0x7f01014c;
    public static final int layout_insetEdge=0x7f01014b;
    public static final int layout_keyline=0x7f010149;
    public static final int statusBarBackground=0x7f010146;
    public static final int ttcIndex=0x7f010157;
  }

  public static class color {
    public static final int notification_action_color_filter=0x7f0b003c;
    public static final int notification_icon_bg_color=0x7f0b003d;
    public static final int ripple_material_light=0x7f0b0031;
    public static final int secondary_text_default_material_light=0x7f0b0033;
  }

  public static class dimen {
    public static final int compat_button_inset_horizontal_material=0x7f080063;
    public static final int compat_button_inset_vertical_material=0x7f080064;
    public static final int compat_button_padding_horizontal_material=0x7f080065;
    public static final int compat_button_padding_vertical_material=0x7f080066;
    public static final int compat_control_corner_material=0x7f080067;
    public static final int compat_notification_large_icon_max_height=0x7f080068;
    public static final int compat_notification_large_icon_max_width=0x7f080069;
    public static final int notification_action_icon_size=0x7f08006a;
    public static final int notification_action_text_size=0x7f08006b;
    public static final int notification_big_circle_margin=0x7f08006c;
    public static final int notification_content_margin_start=0x7f080060;
    public static final int notification_large_icon_height=0x7f08006d;
    public static final int notification_large_icon_width=0x7f08006e;
    public static final int notification_main_column_padding_top=0x7f080061;
    public static final int notification_media_narrow_margin=0x7f080062;
    public static final int notification_right_icon_size=0x7f08006f;
    public static final int notification_right_side_padding_top=0x7f08005f;
    public static final int notification_small_icon_background_padding=0x7f080070;
    public static final int notification_small_icon_size_as_large=0x7f080071;
    public static final int notification_subtext_size=0x7f080072;
    public static final int notification_top_pad=0x7f080073;
    public static final int notification_top_pad_large_text=0x7f080074;
  }

  public static class drawable {
    public static final int abc_vector_test=0x7f020055;
    public static final int notification_action_background=0x7f020060;
    public static final int notification_bg=0x7f020061;
    public static final int notification_bg_low=0x7f020062;
    public static final int notification_bg_low_normal=0x7f020063;
    public static final int notification_bg_low_pressed=0x7f020064;
    public static final int notification_bg_normal=0x7f020065;
    public static final int notification_bg_normal_pressed=0x7f020066;
    public static final int notification_icon_background=0x7f020067;
    public static final int notification_template_icon_bg=0x7f02006c;
    public static final int notification_template_icon_low_bg=0x7f02006d;
    public static final int notification_tile_bg=0x7f020068;
    public static final int notify_panel_notification_icon_bg=0x7f020069;
  }

  public static class id {
    public static final int action_container=0x7f0c00ac;
    public static final int action_divider=0x7f0c00b7;
    public static final int action_image=0x7f0c00ad;
    public static final int action_text=0x7f0c00ae;
    public static final int actions=0x7f0c00b8;
    public static final int async=0x7f0c0073;
    public static final int blocking=0x7f0c0074;
    public static final int bottom=0x7f0c0057;
    public static final int chronometer=0x7f0c00b6;
    public static final int end=0x7f0c004a;
    public static final int forever=0x7f0c0075;
    public static final int icon=0x7f0c007f;
    public static final int icon_group=0x7f0c00b9;
    public static final int info=0x7f0c00b2;
    public static final int italic=0x7f0c0076;
    public static final int left=0x7f0c0059;
    public static final int line1=0x7f0c002a;
    public static final int line3=0x7f0c002b;
    public static final int none=0x7f0c003c;
    public static final int normal=0x7f0c0038;
    public static final int notification_background=0x7f0c00b4;
    public static final int notification_main_column=0x7f0c00b0;
    public static final int notification_main_column_container=0x7f0c00af;
    public static final int right=0x7f0c005a;
    public static final int right_icon=0x7f0c00b3;
    public static final int right_side=0x7f0c00b1;
    public static final int start=0x7f0c005b;
    public static final int tag_transition_group=0x7f0c0031;
    public static final int tag_unhandled_key_event_manager=0x7f0c0032;
    public static final int tag_unhandled_key_listeners=0x7f0c0033;
    public static final int text=0x7f0c0034;
    public static final int text2=0x7f0c0035;
    public static final int time=0x7f0c00b5;
    public static final int title=0x7f0c0036;
    public static final int top=0x7f0c0058;
  }

  public static class integer {
    public static final int status_bar_notification_info_maxnum=0x7f0d0004;
  }

  public static class layout {
    public static final int notification_action=0x7f04001e;
    public static final int notification_action_tombstone=0x7f04001f;
    public static final int notification_template_custom_big=0x7f040020;
    public static final int notification_template_icon_group=0x7f040021;
    public static final int notification_template_part_chronometer=0x7f040022;
    public static final int notification_template_part_time=0x7f040023;
  }

  public static class string {
    public static final int status_bar_notification_info_overflow=0x7f07001c;
  }

  public static class style {
    public static final int TextAppearance_Compat_Notification=0x7f090155;
    public static final int TextAppearance_Compat_Notification_Info=0x7f090156;
    public static final int TextAppearance_Compat_Notification_Line2=0x7f09015b;
    public static final int TextAppearance_Compat_Notification_Time=0x7f090157;
    public static final int TextAppearance_Compat_Notification_Title=0x7f090158;
    public static final int Widget_Compat_NotificationActionContainer=0x7f090159;
    public static final int Widget_Compat_NotificationActionText=0x7f09015a;
    public static final int Widget_Support_CoordinatorLayout=0x7f090154;
  }

  public static class styleable {
    public static final int[] AnimatedStateListDrawableCompat={ 0x0101011c, 0x01010194, 0x01010195, 0x01010196, 0x0101030c, 0x0101030d };
    public static final int AnimatedStateListDrawableCompat_android_constantSize=3;
    public static final int AnimatedStateListDrawableCompat_android_dither=0;
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration=4;
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration=5;
    public static final int AnimatedStateListDrawableCompat_android_variablePadding=2;
    public static final int AnimatedStateListDrawableCompat_android_visible=1;
    public static final int[] AnimatedStateListDrawableItem={ 0x010100d0, 0x01010199 };
    public static final int AnimatedStateListDrawableItem_android_drawable=1;
    public static final int AnimatedStateListDrawableItem_android_id=0;
    public static final int[] AnimatedStateListDrawableTransition={ 0x01010199, 0x01010449, 0x0101044a, 0x0101044b };
    public static final int AnimatedStateListDrawableTransition_android_drawable=0;
    public static final int AnimatedStateListDrawableTransition_android_fromId=2;
    public static final int AnimatedStateListDrawableTransition_android_reversible=3;
    public static final int AnimatedStateListDrawableTransition_android_toId=1;
    public static final int[] ColorStateListItem={ 0x010101a5, 0x0101031f, 0x7f01014d };
    public static final int ColorStateListItem_alpha=2;
    public static final int ColorStateListItem_android_alpha=1;
    public static final int ColorStateListItem_android_color=0;
    public static final int[] CoordinatorLayout={ 0x7f010145, 0x7f010146 };
    public static final int[] CoordinatorLayout_Layout={ 0x010100b3, 0x7f010147, 0x7f010148, 0x7f010149, 0x7f01014a, 0x7f01014b, 0x7f01014c };
    public static final int CoordinatorLayout_Layout_android_layout_gravity=0;
    public static final int CoordinatorLayout_Layout_layout_anchor=2;
    public static final int CoordinatorLayout_Layout_layout_anchorGravity=4;
    public static final int CoordinatorLayout_Layout_layout_behavior=1;
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges=6;
    public static final int CoordinatorLayout_Layout_layout_insetEdge=5;
    public static final int CoordinatorLayout_Layout_layout_keyline=3;
    public static final int CoordinatorLayout_keylines=0;
    public static final int CoordinatorLayout_statusBarBackground=1;
    public static final int[] FontFamily={ 0x7f01014e, 0x7f01014f, 0x7f010150, 0x7f010151, 0x7f010152, 0x7f010153 };
    public static final int[] FontFamilyFont={ 0x01010532, 0x01010533, 0x0101053f, 0x0101056f, 0x01010570, 0x7f010039, 0x7f010154, 0x7f010155, 0x7f010156, 0x7f010157 };
    public static final int FontFamilyFont_android_font=0;
    public static final int FontFamilyFont_android_fontStyle=2;
    public static final int FontFamilyFont_android_fontVariationSettings=4;
    public static final int FontFamilyFont_android_fontWeight=1;
    public static final int FontFamilyFont_android_ttcIndex=3;
    public static final int FontFamilyFont_font=7;
    public static final int FontFamilyFont_fontStyle=6;
    public static final int FontFamilyFont_fontVariationSettings=5;
    public static final int FontFamilyFont_fontWeight=8;
    public static final int FontFamilyFont_ttcIndex=9;
    public static final int FontFamily_fontProviderAuthority=0;
    public static final int FontFamily_fontProviderCerts=3;
    public static final int FontFamily_fontProviderFetchStrategy=4;
    public static final int FontFamily_fontProviderFetchTimeout=5;
    public static final int FontFamily_fontProviderPackage=1;
    public static final int FontFamily_fontProviderQuery=2;
    public static final int[] GradientColor={ 0x0101019d, 0x0101019e, 0x010101a1, 0x010101a2, 0x010101a3, 0x010101a4, 0x01010201, 0x0101020b, 0x01010510, 0x01010511, 0x01010512, 0x01010513 };
    public static final int[] GradientColorItem={ 0x010101a5, 0x01010514 };
    public static final int GradientColorItem_android_color=0;
    public static final int GradientColorItem_android_offset=1;
    public static final int GradientColor_android_centerColor=7;
    public static final int GradientColor_android_centerX=3;
    public static final int GradientColor_android_centerY=4;
    public static final int GradientColor_android_endColor=1;
    public static final int GradientColor_android_endX=10;
    public static final int GradientColor_android_endY=11;
    public static final int GradientColor_android_gradientRadius=5;
    public static final int GradientColor_android_startColor=0;
    public static final int GradientColor_android_startX=8;
    public static final int GradientColor_android_startY=9;
    public static final int GradientColor_android_tileMode=6;
    public static final int GradientColor_android_type=2;
    public static final int[] StateListDrawable={ 0x0101011c, 0x01010194, 0x01010195, 0x01010196, 0x0101030c, 0x0101030d };
    public static final int[] StateListDrawableItem={ 0x01010199 };
    public static final int StateListDrawableItem_android_drawable=0;
    public static final int StateListDrawable_android_constantSize=3;
    public static final int StateListDrawable_android_dither=0;
    public static final int StateListDrawable_android_enterFadeDuration=4;
    public static final int StateListDrawable_android_exitFadeDuration=5;
    public static final int StateListDrawable_android_variablePadding=2;
    public static final int StateListDrawable_android_visible=1;
  }

}
