package com.pedroimai.okbucktutorial;

public class R {
  public static class color {
    public static final int colorAccent=0x7f0b0040;
    public static final int colorPrimary=0x7f0b003e;
    public static final int colorPrimaryDark=0x7f0b003f;
  }

  public static class drawable {
    public static final int ic_launcher_background=0x7f02005e;
    public static final int ic_launcher_foreground=0x7f02005f;
  }

  public static class layout {
    public static final int activity_main=0x7f04001c;
  }

  public static class mipmap {
    public static final int ic_launcher=0x7f030000;
    public static final int ic_launcher_round=0x7f030001;
  }

  public static class string {
    public static final int app_name=0x7f07001d;
  }

  public static class style {
    public static final int AppTheme=0x7f09015c;
  }

}
